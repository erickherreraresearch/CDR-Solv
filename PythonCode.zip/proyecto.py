# -*- coding: utf-8 -*-
"""
Created on Thu May 16 13:32:19 2024
@author: gab_4
"""
import os
import numpy as np
# import pandas as pd
from numpy import array
import matplotlib.pyplot as plt
import tkinter as tk
# import pandas as pd
import customtkinter
from customtkinter import CTkButton as button
# from customtkinter import CTkEntry as entry
from customtkinter import CTkFrame as frame
from customtkinter import CTkComboBox as combobox
from customtkinter import CTkFont as font
from customtkinter import CTkLabel as label
from PIL import Image
import json
import importlib
# from IPython.display import HTML
# from matplotlib import animation
from sympy import sympify, latex
# import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
# import addcopyfighandler
from time import sleep

PRINT_Z = 0



# ///////////////////////////////////////////////////////////////////////
# ///////////////////////////////////////////////////////////////////////
# ///////////////////////////////////////////////////////////////////////
def Nodos(n, p, lx, ly, **kwargs):
    # creacion de la Malla
    #
    # entradas:
    #  lx: longitud en x del rectángulo
    #  ly: longitud en y del rectángulo
    #  n: número de partes en que se divide el segmento [0,lx] y [0,ly]
    #  p: Grado del polinomio
    #
    # salida:
    #  las coordenadas de cada nodo se almacenan en el vector X.
    x = np.linspace(0, lx, n*p+1)
    y = np.linspace(0, ly, n*p+1)
    X = np.zeros([(n*p+1)**2, 2])
    i = 0
    for j in range(n*p+1):
        for k in range(n*p+1):
            X[i, 0] = x[j]
            X[i, 1] = y[k]
            i += 1
    return X

def Tc3(n, p, **kwargs):
    # para generar la matriz de conectividad
    #
    # entradas:
    #  n: número de partes en que se divide el segmento [0,lx] y [0,ly]
    #  p: Grado del polinomio
    #
    # salida:
    #  t3 es la matriz de conectividad, con todos los nodos de cada elemento
    #  triangular

    nff = [3, 6, 10, 15]
    k = 1
    T3 = np.zeros((2 * n**2, nff[p-1]), dtype=int)

    if p == 1:
        for i in range(1, n+1):
            for j in range(1, n+1):
                T3[k-1, 0] = (j-1)*p + 1 + (n*p+1)*(i-1)*p
                T3[k-1, 1] = T3[k-1, 0] + (n*p+1)*p
                T3[k-1, 2] = T3[k-1, 1] + p
                k += 1
                T3[k-1, 0] = T3[k-2, 0]
                T3[k-1, 1] = T3[k-1, 0] + n + 2
                T3[k-1, 2] = T3[k-1, 0] + 1
                k += 1

    elif p == 2:
        for i in range(1, n+1):
            for j in range(1, n+1):
                T3[k-1, 0] = (j-1)*p + 1 + (n*p+1)*(i-1)*p
                T3[k-1, 1] = T3[k-1, 0] + (n*p+1)*p
                T3[k-1, 2] = T3[k-1, 1] + p
                T3[k-1, 3] = T3[k-1, 0] + (n*p+1)
                T3[k-1, 4] = T3[k-1, 1] + 1
                T3[k-1, 5] = T3[k-1, 3] + 1
                k += 1
                T3[k-1, 0] = T3[k-2, 0]
                T3[k-1, 1] = T3[k-2, 2]
                T3[k-1, 2] = T3[k-2, 0] + p
                T3[k-1, 3] = T3[k-2, 3] + 1
                T3[k-1, 4] = T3[k-1, 3] + 1
                T3[k-1, 5] = T3[k-1, 0] + 1
                k += 1

    elif p == 3:
        for i in range(1, n+1):
            for j in range(1, n+1):
                T3[k-1, 0] = (j-1)*p + 1 + (n*p+1)*(i-1)*p
                T3[k-1, 1] = T3[k-1, 0] + (n*p+1)*p
                T3[k-1, 2] = T3[k-1, 1] + p
                T3[k-1, 3] = T3[k-1, 0] + (n*p+1)
                T3[k-1, 4] = T3[k-1, 3] + (n*p+1)
                T3[k-1, 5] = T3[k-1, 1] + 1
                T3[k-1, 6] = T3[k-1, 5] + 1
                T3[k-1, 7] = T3[k-1, 6] - (n*p+1)
                T3[k-1, 8] = T3[k-1, 3] + 1
                T3[k-1, 9] = T3[k-1, 4] + 1
                k += 1
                T3[k-1, 0] = T3[k-2, 0]
                T3[k-1, 1] = T3[k-2, 2]
                T3[k-1, 2] = T3[k-2, 0] + p
                T3[k-1, 3] = T3[k-2, 8]
                T3[k-1, 4] = T3[k-2, 7]
                T3[k-1, 5] = T3[k-1, 4] + 1
                T3[k-1, 6] = T3[k-1, 5] - (n*p+1)
                T3[k-1, 7] = T3[k-1, 2] - 1
                T3[k-1, 8] = T3[k-1, 7] - 1
                T3[k-1, 9] = T3[k-1, 3] + 1
                k += 1
    return T3


def cccnpg(Xe, i):
    # Mapeo o transformación de coordenadas cartesianas a coordenadas naturales en un
    # punto de Gauss
    # Xe: Coordenadas cartesianas del elemento triangular.
    # p: grado del polinomio interpolante de las funciones de forma.
    # pg: punto de gauss
    # i: ubicación del punto de gauss pg en la matriz z de puntos de gauss.
    # e: Transformación isoparamétrica de x en coordenas naturales, y evaluada en el punto de Gauss i
    # n: Transformación isoparamétrica de y en coordenas naturales, y evaluada en el punto de Gauss i
    w, z = gauss2DT()
    xen = Xe[0, 0] + z[i, 0] * \
        (Xe[1, 0] - Xe[0, 0]) + z[i, 1] * (Xe[2, 0] - Xe[0, 0])
    yen = Xe[0, 1] + z[i, 0] * \
        (Xe[1, 1] - Xe[0, 1]) + z[i, 1] * (Xe[2, 1] - Xe[0, 1])
    return xen, yen


def kefe2DT(Xe, n, p, k, a, s, w, N, dN, d2N, fxy, **kwargs):
    #
    # entradas:
    #  ke: Matriz del elemento e
    #  fe: Vector de fuerzas del elemento e
    #  Xe: Matriz con las coordenadas de los nodos del elemento e
    #  p: Grado polinómico de las funciones de forma.
    #  k,a,s: Constantes de la ecuación diferencial Cdr
    #  w,z: Pesos y puntos de Gauss
    #  N,dN,d2N: Valores en los puntos de Gauss para todos los grados polinómicos
    #     de las funciones de forma (N) y de sus derivadas parciales de primer orden dN y de
    #     segundo orden d2N
    #
    # salidas:
    #  ke: matriz elemental
    #  fe: vector de fuerza

    # Jacobiano
    J = np.array([[Xe[1, 0]-Xe[0, 0], Xe[1, 1]-Xe[0, 1]],
                  [Xe[2, 0]-Xe[0, 0], Xe[2, 1]-Xe[0, 1]]])
    detJ = J[0, 0]*J[1, 1] - J[0, 1]*J[1, 0]

    # Inversa del Jacobiano
    IJ = np.array([[J[1, 1], -J[0, 1]], [-J[1, 0], J[0, 0]]]) / detJ

    h = 1/(n)
    c1 = 4#12
    c2 = 2
    ac = (a[0]**2 + a[1]**2)**0.5
    Tk = (c1*k*p**4/h**2 + c2*ac*p/h)**(-1)

    # Numero de funciones de forma para cada p
    nff = [3, 6, 10, 15]

    if p == 1:
        cff = 0
        cp = 0
        npp = 7
        fp = 1
    elif p == 2:
        cff = 3
        cp = 0
        npp = 7
        fp = 1
    elif p == 3:
        cff = 9
        cp = 0
        npp = 7
        fp = 1

    fe = np.zeros(nff[p-1])
    ke = np.zeros((nff[p-1], nff[p-1]))

    for i in range(nff[p-1]):  # controls rows
        for pg in range(npp):  # controls Gauss points
            e, n = cccnpg(Xe, pg+cp)
            d1 = np.array([dN[cff+i, 2*pg], dN[cff+i, 2*pg+1]])
            hs1 = np.array([[d2N[cff+i, 3*pg],
                             d2N[cff+i, 3*pg+1]],
                           [d2N[cff+i, 3*pg+2],
                            d2N[cff+i, 3*pg+1]]])
            j1 = IJ @ ((IJ @ hs1).T)
            Tr1 = j1[0, 0] + j1[1, 1]
            # print(fe[i])
            fe[i] += (N[cff+i, pg] + Tk*(k*Tr1 + a@(IJ@d1) - s*N[cff+i, pg])) * fxy(e, n, **var_dict) * w[fp-1][pg]
        fe[i] *= detJ

        for j in range(nff[p-1]):  # controls columns
            for pg in range(npp):  # controls Gauss points
                d1 = np.array([dN[cff+i, 2*pg], dN[cff+i, 2*pg+1]])
                d2 = np.array([dN[cff+j, 2*pg], dN[cff+j, 2*pg+1]])
                hs1 = np.array([[d2N[cff+i, 3*pg], d2N[cff+i, 3*pg+1]],
                               [d2N[cff+i, 3*pg+2], d2N[cff+i, 3*pg+1]]])
                hs2 = np.array([[d2N[cff+j, 3*pg], d2N[cff+j, 3*pg+1]],
                               [d2N[cff+j, 3*pg+2], d2N[cff+j, 3*pg+1]]])
                j1 = IJ @ (IJ @ hs1.T)
                Tr1 = j1[0, 0] + j1[1, 1]
                j2 = IJ @ (IJ @ hs2.T)
                Tr2 = j2[0, 0] + j2[1, 1]
                Par1 = k*Tr1 + a @ (IJ @ d1) - s*N[cff+i, pg]
                Par2 = -k*Tr2 + a @ (IJ @ d2) + s*N[cff+j, pg]
                ke[i, j] += (k*((IJ @ d1) @ (IJ @ d2)) + N[cff+i, pg]*a @ (IJ @ d2) +
                             s*N[cff+i, pg]*N[cff+j, pg] + Tk*Par1*Par2)*w[fp-1, pg]
            ke[i, j] *= detJ
    return ke, fe

def ffT(ee, nn, p):
    # genera las funciones de forma y sus derivadas en el punto y grado dado
    # entradas:
    #  e y n: coordenadas naturales
    #  p: grado polinomico
    #
    # salidas:
    #  N: función de forma en el punto
    #  dN: primera derivada
    #  dN2: segunda derivada

    if p == 1:
        N = np.array([1-ee-nn,
                      ee,
                      nn])
        dN = np.array([[-1, -1],
                       [1, 0],
                       [0, 1]])
        d2N = np.zeros((3, 3))
    elif p == 2:
        N = np.array([(1-ee-nn)*(1-2*ee-2*nn),
                      ee*(2*ee-1),
                      nn*(2*nn-1),
                      4*ee*(1-ee-nn),
                      4*ee*nn,
                      4*nn*(1-ee-nn)])
        dN = np.array([[4*ee + 4*nn - 3, 4*ee + 4*nn - 3],
                       [4*ee - 1, 0],
                       [0, 4*nn - 1],
                       [-8*ee - 4*nn + 4, -4*ee],
                       [4*nn, 4*ee],
                       [-4*nn, -4*ee - 8*nn + 4]])
        d2N = np.array([[4, 4, 4],
                        [4, 0, 0],
                        [0, 4, 0],
                        [-8, 0, -4],
                        [0, 0, 4],
                        [0, -8, -4]])
    elif p == 3:
        N = np.array([9/2*(1-ee-nn)*(1/3-ee-nn)*(2/3-ee-nn),
                      9/2*ee*(ee-1/3)*(ee-2/3),
                      9/2*nn*(nn-1/3)*(nn-2/3),
                      27/2*(ee+nn-1)*ee*(ee+nn-2/3),
                      27/2*(1-ee-nn)*ee*(ee-1/3),
                      27/2*ee*nn*(ee-1/3),
                      27/2*ee*nn*(nn-1/3),
                      27/2*(1-ee-nn)*nn*(nn-1/3),
                      27/2*(ee+nn-1)*nn*(ee+nn-2/3),
                      27*ee*nn*(1-ee-nn)])
        dN = np.array([[-27/2*ee**2-27*ee*nn+18*ee-27/2*nn**2+18*nn-11/2, -27/2*ee**2-27*ee*nn+18*ee-27/2*nn**2+18*nn-11/2],
                       [27/2*ee**2 - 9*ee + 1, 0],
                       [0, 27/2*nn**2 - 9*nn + 1],
                       [81/2*ee**2 + 54*ee*nn - 45*ee + 27/2*nn**2 - 45/2*nn + 9, 27*ee**2 + 27*ee*nn - 45/2*ee],
                       [-81/2*ee**2 - 27*ee*nn + 36*ee + 9/2*nn - 9/2, 9/2*ee - 27/2*ee**2],
                       [27*ee*nn - 9/2*nn, 27/2*ee**2 - 9/2*ee],
                       [27/2*nn**2 - 9/2*nn, 27*ee*nn - 9/2*ee],
                       [9/2*nn - 27/2*nn**2, -27*ee*nn + 9/2*ee - 81/2*nn**2 + 36*nn - 9/2],
                       [27*ee*nn + 27 * nn**2 - 45/2*nn, 27/2*ee**2 + 54*ee*nn - 45/2*ee + 81/2*nn**2 - 45*nn + 9],
                       [-54*ee*nn - 27*nn**2 + 27*nn, -27*ee**2 - 54*ee*nn + 27*ee]
                      ])
        d2N = np.array([[-27*ee - 27*nn + 18, -27*ee - 27*nn + 18, -27*ee - 27*nn + 18],
                        [27*ee - 9, 0, 0],
                        [0, 27*nn - 9, 0],
                        [81*ee + 54*nn - 45, 27*ee, 54*ee + 27*nn - 45 /2],
                        [-81*ee - 27*nn + 36, 0, -27*ee + 9/2],
                        [27*nn, 0, 27*ee - 9/2],
                        [0, 27*ee, 27*nn - 9 /2],
                        [0, -27*ee - 81*nn + 36, -27*nn + 9/2],
                        [27*nn, 54*ee + 81*nn - 45, 27*ee + 54*nn - 45/2],
                        [-54*nn, -54*ee, -54*ee - 54*nn + 27]
                       ])
    return N, dN, d2N


def vffydp2DT():
    # cálculo de los valores en los puntos de gauss de las
    # funciones de forma y de sus derivadas parciales en 2D para elementos
    # triangulares y para todos los grados polinómicos
    #
    # salidas:
    #  N: funcion de forma para todos los puntos de Gauss y todos los p
    #  dN: primera derivada de N
    #  d2N: segunda derivada de N
    N = np.zeros((34, 13))
    dN = np.zeros((34, 26))
    d2N = np.zeros((34, 39))
    nff = [3, 6, 10, 15]
    w, z = gauss2DT()
    cf = 0
    cp = 0
    npp = 7
    for p_ in range(3):
        for i in range(npp):  # loop for number of Gauss points
            N1, dN1, d2N1 = ffT(z[i+cp, 0], z[i+cp, 1], p_+1)
            # print('\n\n')
            # print(f'{p_=}  ({z[i+cp, 0]:.3f}, {z[i+cp, 1]:.3f}):')
            # print('N')
            # print_mat(N1, dec=4)
            # print('\ndN')
            # print_mat(dN1, dec=4)
            # print('\nd2N')
            # print_mat(d2N1, dec=4)
            # print('\n\n')
            N[  cf:cf+nff[p_], i] = N1
            dN[ cf:cf+nff[p_], i*2+0] = dN1[ :, 0]
            dN[ cf:cf+nff[p_], i*2+1] = dN1[ :, 1]
            d2N[cf:cf+nff[p_], i*3+0] = d2N1[:, 0]
            d2N[cf:cf+nff[p_], i*3+1] = d2N1[:, 1]
            d2N[cf:cf+nff[p_], i*3+2] = d2N1[:, 2]
        cf += nff[p_]
    # print('Matriz w:')
    # print_mat(w)
    # print('\n\nMatriz z:')
    # print_mat(z)
    # print('\n\nMatriz N:')
    # print_mat(N)
    # print('\n\nMatriz dN:')
    # print_mat(dN)
    # print('\n\nMatriz d2N:')
    # print_mat(d2N)
    return N, dN, d2N


def gauss2DT():
    # Devuelve las matrices w y z conteniendo los pesos y los puntos de Gauss
    # salidas:
    #  w: pesos de Gauss
    #  z: puntos de Gauss

    wa = (155 - 15**0.5)/2400
    wb = (155 + 15**0.5)/2400
    zb = (9 + 2*15**0.5)/21
    zc = (6 - 15**0.5)/21
    zd = (9 - 2*15**0.5)/21
    ze = (6 + 15**0.5)/21

    a = 0.333333333333333
    b = 0.479308067841920
    c = 0.869739794195568
    d = 0.638444188569810
    e = 0.260345966079040
    f = 0.065130102902216
    g = 0.312865496004874
    h = 0.048690315425316
    w1 = -0.149570044467670/2.0
    w2 = 0.175615257433204/2.0
    w3 = 0.053347235608839/2.0
    w4 = 0.077113760890257/2.0

    w = np.array([
        [9/80, wa, wa, wa, wb, wb, wb, 0, 0, 0, 0, 0, 0],
        [w1, w2, w2, w2, w3, w3, w3, w4, w4, w4, w4, w4, w4]
    ])

    z = np.array([
        [1/3, 1/3],
        [zb, zc],
        [zc, zb],
        [zc, zc],
        [zd, ze],
        [ze, zd],
        [ze, ze],
        [a, a],
        [e, e],
        [b, e],
        [e, b],
        [f, f],
        [c, f],
        [f, c],
        [d, g],
        [d, h],
        [g, d],
        [g, h],
        [h, d],
        [h, g]
    ])
    return w, z


def es2(X, T3, n, p, k, a, s, lx, ly, uxy, draw=1, **kwargs):
    # entradas:
    #  X: matriz con las coordenadas globales de los nodos de la malla
    #  T3: matriz de conectividad de los elementos.
    #  n: número de partes en que se divide el segmento x y el segmento y en
    #        el intervalo  [0,1]x[0,1].
    #  p: grado del polinomio de las funciones de forma.
    #  Xe: matriz de coordenadas locales del elemento triangular.
    #  draw: booleano para graficar
    #
    # salidas:
    #  x1, y1, z: coordenadas tridimensionales de la respuesta

    nff = [3, 6, 10, 15]
    K = np.zeros(((n * p + 1) * (n * p + 1), (n * p + 1) * (n * p + 1)))
    F = np.zeros((n * p + 1) * (n * p + 1))
    Xe = np.zeros((3, 2))
    w, _ = gauss2DT()
    N, dN, d2N = vffydp2DT()

    # print(f'\n\n\n{sep*10}\n {n=}    {p=}\n{sep*10}\n')
    for num_elem, nodes in enumerate(T3):
        # aux = T3[i, :]
        for j in range(3):
            Xe[j, :] = X[nodes[j]-1, :]
        ke, fe = kefe2DT(Xe, w=w, N=N, dN=dN, d2N=d2N, **var_dict)
        # print(f'\n{num_elem+1}° Elemento triangular')
        # print(f'\n  Xe {num_elem+1}:')
        # print_mat(Xe)
        # print(f'\n  ke {num_elem+1}:')
        # print_mat(ke)
        # print(f'\n  fe {num_elem+1}:')
        # print_mat(fe)
        for j in range(nff[p-1]):
            F[nodes[j]-1] += fe[j]
            # print(f'{nodes[j]}) {fe[j]}')
            for m in range(nff[p-1]):
                K[nodes[j]-1, nodes[m]-1] += ke[j, m]
        # print(f'\n{sep*(4*fe.shape[0])}')
    # return 0,0,0

    aux = np.zeros((n * p - 1)**2, dtype=int)
    m = 1
    for i in range(1, n * p):
        for j in range(1, n * p):
            aux[m - 1] = (n * p + 1) * i + j + 1
            m += 1

    KR = np.zeros(((n * p - 1) ** 2, (n * p - 1) ** 2))
    FR = np.zeros((n * p - 1) ** 2)
    for i in range((n * p - 1) ** 2):
        FR[i] = F[aux[i]-1]
        for j in range((n * p - 1) ** 2):
            KR[i, j] = K[aux[i]-1, aux[j]-1]

    # corrección del vector fuerzas por Direchlet
    Uf = np.zeros((n * p + 1) ** 2)
    b = np.zeros(4 * n * p, dtype=int)
    m = 1
    x = np.linspace(0, lx, n * p + 1)
    y = np.linspace(0, ly, n * p + 1)

    # Generación de las condiciones de Dirichlet en frontera
    for i in range(n * p + 1):
        b[m - 1] = i
        Uf[i] = uxy(0, y[i], **var_dict)
        m += 1
    for i in range(1, n * p):
        b[m - 1] = i * (n * p + 1) + 1
        Uf[b[m - 1]] = uxy(x[i], 0, **var_dict)
        m += 1
    for i in range(1, n * p):
        b[m - 1] = (i + 1) * (n * p + 1)
        Uf[b[m - 1]] = uxy(x[i], ly, **var_dict)
        m += 1
    for i in range(n * p + 1):
        b[m - 1] = (n * p + 1) * (n * p) + i
        Uf[b[m - 1]] = uxy(lx, y[i], **var_dict)
        m += 1

    # Corrección del vector de fuerzas FR
    for i in range((n * p - 1) ** 2):
        for j in range(4 * n * p):
            FR[i] -= K[aux[i]-1, b[j]] * Uf[b[j]]

    Uc = np.linalg.solve(KR, FR.T)
    for i in range((n * p - 1) ** 2):
        Uf[aux[i]-1] = Uc[i]

    x = np.linspace(0, lx, n * p + 1)
    y = np.linspace(0, ly, n * p + 1)
    x1, y1 = np.meshgrid(x, y)
    z = np.zeros((n * p + 1, n * p + 1))
    for i in range(n * p + 1):
        for j in range(n * p + 1):
            idx = (n * p + 1) * (i) + j
            # print(idx)
            z[j, i] = Uf[idx]

    if draw:
        # Objeto para gráficos
        fig = plt.figure(figsize=(12, 8))
        ax = plt.axes(projection='3d')

        # Mapa de color
        my_cmap = plt.get_cmap('winter')

        # 3d superficie
        surf = ax.plot_surface(x1, y1, z,
                               cmap=my_cmap,
                               edgecolor='none')
        fig.colorbar(surf, ax=ax,
                     shrink=0.5, aspect=5)
        print('\n\nGráfico 3D de contorno:')
        print(f'datos ingresados:\n\t{k=}, {s=}, {a=}, {lx=}, {ly=}')
        print(f'\t{n=},   {p=}')
        fxy_ = var_dict['fxy_txt']
        print(f'fxy: {fxy_}')
        uxy_ = var_dict['uxy_txt']
        print(f'uxy: {uxy_}')
        title_txt = '$\\bf{k}$='f'{k}   ''$\\bf{s}$='f'{s}   ''$\\bf{a}$='f'({a[0]}; {a[1]})  ''$\\bf{n}$='f'{n}  ''$\\bf{p}$='f'{p}  ''$\\bf{f}$='f'{fxy_}   ''$\\bf{u}$='f'{uxy_}'
        ax.set_title(title_txt)
        ax.view_init(elev=30, azim=200)
        plt.show()

        # 2d contorno
        plt.figure()
        ax = plt.axes()
        ax.set_title(title_txt+'\n')
        plt.contour(z)
        plt.show()

    return x1, y1, z

# ///////////////////////////////////////////////////////////////////////
# ///////////////////////////////////////////////////////////////////////
# ///////////////////////////////////////////////////////////////////////


class CustomError(Exception):
    pass

# clear screen
os.system('cls')

# init strs
sep = '__'
time_between = 0.5

# cwd
print(os.getcwd())

# load saved data
with open('saved_data.json', 'r+') as file_in:
    data_json = json.load(file_in)

# tkinter init
customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("blue")
general = {}

def print_mat(mat, total=7, dec=1, row_start=0, row_end=500, col_start=0, col_end=100):
    skipped_rows = False
    skipped_cols = False
    for num_col,row in enumerate(mat):
        if num_col<row_start or num_col>=row_end:
            skipped_rows = True
            continue
        try:
            for num_row, elem in enumerate(row):
                if num_row<col_start or num_row>=col_end:
                    skipped_cols = True
                    continue
                if abs(elem)<0.00001:
                    blank = '*'
                    print(f'{blank:{total}}', end=' ')
                else:
                    print(f'{elem:{total}.{dec}f}', end=' ')
            print('')
        except:
            print(f'{row:{total}.{dec}f}', end=' ')
    if skipped_rows:
        print('\n\nROWS SKIPPED')
    if skipped_cols:
        print('\n\nCOLS SKIPPED')

# GUI
class CreateToolTip(object):
    """
    create a tooltip for a given widget
    """
    def __init__(self, widget, text='widget info'):
        self.waittime = 150     #miliseconds
        self.wraplength = 180   #pixels
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.leave)
        self.widget.bind("<ButtonPress>", self.leave)
        self.id = None
        self.tw = None

    def enter(self, event=None):
        self.schedule()

    def leave(self, event=None):
        self.unschedule()
        self.hidetip()

    def schedule(self):
        self.unschedule()
        self.id = self.widget.after(self.waittime, self.showtip)

    def unschedule(self):
        id = self.id
        self.id = None
        if id:
            self.widget.after_cancel(id)

    def showtip(self, event=None):
        x = y = 0
        x, y, cx, cy = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        # creates a toplevel window
        self.tw = tk.Toplevel(self.widget)
        # Leaves only the label and removes the app window
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))
        label = tk.Label(self.tw, text=self.text, justify='left',
                       background="#ffffff", relief='solid', borderwidth=1,
                       wraplength = self.wraplength)
        label.pack(ipadx=1)

    def hidetip(self):
        tw = self.tw
        self.tw= None
        if tw:
            tw.destroy()

def img(path, sizex, sizey):
    return customtkinter.CTkImage(Image.open(path), size=(sizex, sizey))


def next_row(num):
    while 1:
        num += 1
        yield num

#  resolve
def solve_one():
    plt.close('all')
    X = Nodos(**var_dict)
    T3 = Tc3(**var_dict)
    x1, y1, z = es2(X, T3, **var_dict, draw=1)
    if PRINT_Z:
        print('\n'*2,'Z:')
        print_mat(z, dec=4)
        print('\n'*10)

main_row = next_row(0)

# 1° GUI
general['config_1'] = customtkinter.CTk()
config1 = general['config_1']
config1.title("Config 1")
config1.grid_columnconfigure(0, weight=1)
config1.grid_rowconfigure(0, weight=5)

# title
font_title = font(size=25, weight='bold', slant='roman', underline=False)
txt = 'ECUACIÓN CONVECCIÓN-DIFUSIÓN-REACCIÓN'
title1 = label(config1, text=txt, font=font_title)
title1.grid(row=next(main_row), column=0, sticky='s', padx=30, pady=2)
font_subtitle = font(size=10, weight='bold', slant='roman', underline=False)
txt = 'MÉTODO ESTABILIZADO ASGS DE ELEMENTOS FINITOS'
title2 = label(config1, text=txt, font=font_subtitle)
title2.grid(row=next(main_row), column=0, sticky='n', padx=30, pady=2)

# ecuación
txt = '-k*Laplaciano(u) + a*Gradiente(u) + s*u = f'
title2 = label(config1, text=txt, font=font_title)
title2.grid(row=next(main_row), column=0, sticky='ns', padx=10, pady=10)

# data entry
font_in = font(size=14, weight='bold', slant='roman', underline=False)
widths = 130
entry_frame = frame(config1, fg_color=None)
entry_frame.grid(row=next(main_row), column=0, sticky='nwse', padx=10, pady=10)
entry_row = next_row(0)

# img 1
triple_row = next(entry_row)
img1 = img('2d_ducto.png', sizex=248, sizey=179)
ducto_img = label(entry_frame, text="", image=img1)
ducto_img.grid(row=triple_row, column=0, rowspan=2, columnspan=3, sticky='NE', padx=10, pady=10)

# img data frame
img_frame = frame(entry_frame, fg_color=None)
img_frame.grid(row=triple_row, column=3, sticky='nwse', padx=10, pady=10)
img_row = next_row(0)

# ax
ax_descript = 'velocidad de flujo horizontal'
row = next(img_row)
ax_label = label(img_frame, text='ax=', font=font_in)
ax_label.grid(row=row, column=0, sticky='e', padx=10, pady=10)
ax_label_ttp = CreateToolTip(ax_label, ax_descript)
ax_list = data_json['ax']
ax_box = combobox(img_frame, corner_radius=3, font=font_in, values=ax_list, width=widths)
ax_box_ttp = CreateToolTip(ax_box, ax_descript)
ax_box.set(ax_list[0])
ax_box.grid(row=row, column=1, columnspan=2, sticky='we', padx=10, pady=10)
# ay
ay_descript = 'velocidad de flujo vertical'
row = next(img_row)
ay_label = label(img_frame, text='ay=', font=font_in)
ay_label.grid(row=row, column=0, sticky='e', padx=10, pady=10)
ay_label_ttp = CreateToolTip(ay_label, ay_descript)
ay_list = data_json['ay']
ay_box = combobox(img_frame, corner_radius=3, font=font_in, values=ay_list, width=widths)
ay_box_ttp = CreateToolTip(ay_box, ay_descript)
ay_box.set(ay_list[0])
ay_box.grid(row=row, column=1, columnspan=2, sticky='we', padx=10, pady=10)

# lx
lx_descript = 'longitud horizontal del ducto'
row = next(img_row)
lx_label = label(img_frame, text='lx=', font=font_in)
lx_label.grid(row=row, column=0, sticky='e', padx=10, pady=10)
lx_label_ttp = CreateToolTip(lx_label, lx_descript)
lx_list = data_json['lx']
lx_box = combobox(img_frame, corner_radius=3, font=font_in, values=lx_list, width=widths)
lx_box_ttp = CreateToolTip(lx_box, lx_descript)
lx_box.grid(row=row, column=1, columnspan=2, sticky='we', padx=10, pady=10)
lx_box.set(lx_list[0])
# ly
ly_descript = 'longitud vertical del ducto'
row = next(img_row)
ly_label = label(img_frame, text='ly=', font=font_in)
ly_label.grid(row=row, column=0, sticky='e', padx=10, pady=10)
ly_label_ttp = CreateToolTip(ly_label, ly_descript)
ly_list = data_json['ly']
ly_box = combobox(img_frame, corner_radius=3, font=font_in, values=ly_list, width=widths)
ly_box_ttp = CreateToolTip(ly_box, ly_descript)
ly_box.grid(row=row, column=1, columnspan=2, sticky='we', padx=10, pady=10)
ly_box.set(ly_list[0])

# other data frame
other_frame = frame(entry_frame, fg_color=None)
other_frame.grid(row=triple_row, column=5, sticky='nwse', padx=10, pady=10)
other_row = next_row(0)

#  k
k_descript = 'coeficiente de difusión'
row = next(other_row)
k_label = label(other_frame, text='k=', font=font_in)
k_label.grid(row=row, column=0, sticky='e', padx=10, pady=10)
k_label_ttp = CreateToolTip(k_label, k_descript)
k_list = data_json['k']
k_box = combobox(other_frame, corner_radius=3, font=font_in, values=k_list, width=widths)
k_box.grid(row=row, column=1, columnspan=2, sticky='we', padx=10, pady=10)
k_box_ttp = CreateToolTip(k_box, k_descript)
k_box.set(k_list[0])

# s
s_descript = 'constante s'
row = next(other_row)
s_label = label(other_frame, text='s=', font=font_in)
s_label.grid(row=row, column=0, sticky='e', padx=10, pady=10)
s_label_ttp = CreateToolTip(s_label, s_descript)
s_list = data_json['s']
s_box = combobox(other_frame, corner_radius=3, font=font_in, values=s_list, width=widths)
s_box_ttp = CreateToolTip(s_box, s_descript)
s_box.grid(row=row, column=1, columnspan=2, sticky='we', padx=10, pady=10)
s_box.set(s_list[0])

# n
n_descript = 'número de diviciones para los segmentos lx y ly'
row = next(other_row)
n_label = label(other_frame, text='n=', font=font_in)
n_label.grid(row=row, column=0, sticky='e', padx=10, pady=10)
n_label_ttp = CreateToolTip(n_label, n_descript)
n_list = data_json['n']
n_box = combobox(other_frame, corner_radius=3, font=font_in, values=n_list, width=widths)
n_box_ttp = CreateToolTip(n_box, n_descript)
n_box.grid(row=row, column=1, columnspan=2, sticky='we', padx=10, pady=10)
n_box.set(n_list[0])

# p
p_descript = 'grado polinómico de las funciones de forma'
row = next(other_row)
p_label = label(other_frame, text='p=', font=font_in)
p_label.grid(row=row, column=0, sticky='e', padx=10, pady=10)
p_label_ttp = CreateToolTip(p_label, p_descript)
p_list = ['1', '2', '3']
def verify_p_combobox(num):
    # verify only executes when clicking an element of the options
    if num not in p_list:
        p_box.set(p_list[0])
    else:
        msg_tag.configure(text='')

p_box = combobox(other_frame, corner_radius=3, font=font_in, values=p_list,
                 width=widths, command=verify_p_combobox)
p_box_ttp = CreateToolTip(p_box, p_descript)
p_box.set(data_json['p'])
p_box.grid(row=row, column=1, columnspan=2, sticky='we', padx=10, pady=10)

# other data frame
fuframe = frame(entry_frame, fg_color=None)
fuframe.grid(row=next(entry_row), column=0, columnspan=6, sticky='nwse', padx=1, pady=1)
fu_row = next_row(0)

# fxy
f_u_width = 650
fxy_descript = 'termino fuente o de reacción f, función de las coordenadas (x,y)'
row = next(fu_row)
fxy_label = label(fuframe, text='f(x,y)=', font=font_in)
fxy_label.grid(row=row, column=0, sticky='e', padx=1, pady=10)
fxy_label_ttp = CreateToolTip(fxy_label, fxy_descript)
fig_fxy, axf = plt.subplots(figsize=(7, 0.38))
axf.axis('off')
axf.set_xlim([0, 1])
axf.set_ylim([0, 1])
fxy_canvas = FigureCanvasTkAgg(fig_fxy, fuframe)
def update_fxy(txt):
    try:
        expr = sympify(txt, evaluate=False)
        fig_fxy.clear()
        latex_eq = latex(expr)
        fig_fxy.text(0.5, 0.5,
                 f'$f(x,y)={latex_eq}$',
                 fontsize=14,
                 verticalalignment='center',
                 horizontalalignment='center',)
        fxy_canvas.draw()
    except Exception as e:
        print('fxy error')
fxy_list = data_json['fxy_txt']
if 'fxy.py' not in fxy_list:
    fxy_list.append('fxy.py')
fxy_box = combobox(fuframe, corner_radius=3, font=font_in, values=fxy_list, width=f_u_width, command=update_fxy)
fxy_box_ttp = CreateToolTip(fxy_box, fxy_descript)
fxy_box.grid(row=row, column=1, columnspan=9, sticky='we', padx=1, pady=10)
row = next(fu_row)
fxy_canvas.get_tk_widget().grid(row=row, column=0, columnspan=10, sticky='e', padx=1, pady=3)
def update_fxy2(event=None):
    update_fxy(fxy_box.get())
fxy_box.bind('<KeyRelease>', update_fxy2)
# fxy_box.set('fxy.py')
fxy_box.set(fxy_list[0])
update_fxy2()

# uxy
# uxy_descript = 'función de concetración de calor, a partir de las coordenadas (x,y)'
uxy_descript = 'condiciones de Dirichlet (concentraciones), función de las coordenadas (x,y)'
row = next(fu_row)
uxy_label = label(fuframe, text='u(x,y)=', font=font_in)
uxy_label.grid(row=row, column=0, sticky='e', padx=1, pady=10)
uxy_label_ttp = CreateToolTip(uxy_label, uxy_descript)
fig_uxy, axu = plt.subplots(figsize=(7, 0.38))
axu.axis('off')
axu.set_xlim([0, 1])
axu.set_ylim([0, 1])
uxy_canvas = FigureCanvasTkAgg(fig_uxy, fuframe)
def update_uxy(txt):
    try:
        expr = sympify(txt, evaluate=False)
        fig_uxy.clear()
        latex_eq = latex(expr)
        fig_uxy.text(0.5, 0.5,
                 f'$u(x,y)={latex_eq}$',
                 fontsize=14,
                 verticalalignment='center',
                 horizontalalignment='center',)
        uxy_canvas.draw()
    except Exception as e:
        print('uxy error')
uxy_list = data_json['uxy_txt']
if 'uxy.py' not in uxy_list:
    uxy_list.append('uxy.py')
uxy_box = combobox(fuframe, corner_radius=3, font=font_in, values=uxy_list, width=f_u_width, command=update_uxy)
uxy_box.set(uxy_list[0])
uxy_box_ttp = CreateToolTip(uxy_box, uxy_descript)
uxy_box.grid(row=row, column=1, columnspan=9, sticky='we', padx=1, pady=10)
row = next(fu_row)
uxy_canvas.get_tk_widget().grid(row=row, column=0, columnspan=10, sticky='e', padx=1, pady=3)
def update_uxy2(event=None):
    update_uxy(uxy_box.get())
uxy_box.bind('<KeyRelease>', update_uxy2)
update_uxy2()

# 1 case frame
# one_case_frame = frame(config1, fg_color=None)
# one_case_frame.grid(row=next(main_row), column=0, sticky='nwse', padx=10, pady=10)


var_dict = {}

# msgs part 1
font_msg = font(size=16, weight='bold', slant='italic', underline=False)
msg_tag = label(config1, text='', font=font_msg, text_color='red')
def get_config():
    def data_update(name, value):
        # currently in use
        var_dict[name] = value
        # record data for future auto complete
        if value in data_json[name]:
            data_json[name].remove(value)
        if len(data_json)>3:
            data_json[name] = [str(value)] + data_json[name][1:]
        else:
            data_json[name] = [str(value)] + data_json[name]

    # hide button
    general['start_button'].grid_remove()
    general['loading'].grid(row=general['load_row'], column=0, columnspan=6, sticky='nsew', padx=10, pady=20)

    config1.update()
    config1.update_idletasks()

    p = p_box.get()
    if p not in p_list:
        p_box.set(p_list[0])
        msg_tag.configure(text='El valor de P es incorrecto')
    else:
        var_dict['p'] = int(p)
        data_json['p'] = p # just memory, not list
        k = float(k_box.get())
        data_update('k', k)
        s = float(s_box.get())
        data_update('s', s)
        ax = float(ax_box.get())
        data_update('ax', ax)
        ay = float(ay_box.get())
        data_update('ay', ay)
        a = array([ax, ay])
        var_dict['a'] = a
        lx = float(lx_box.get())
        data_update('lx', lx)
        ly = float(ly_box.get())
        data_update('ly', ly)
        fxy_txt = fxy_box.get()
        data_update('fxy_txt', fxy_txt)
        if '.py' in fxy_txt:
            print('importando fxy')
            fxy = fxy_txt.replace('.py', '')
            fxy = importlib.import_module(fxy)
            fxy = fxy.fxy
        else:
            def fxy(x, y, **kwargs):
                kwargs['x'] = x
                kwargs['y'] = y
                ftxt = fxy_txt
                for key,val in kwargs.items():
                    ftxt = ftxt.replace(key, str(val))
                return eval(ftxt)
            fxy(1,2, k2=1)
        var_dict['fxy'] = fxy

        uxy_txt = uxy_box.get()
        data_update('uxy_txt', uxy_txt)
        if '.py' in uxy_txt:
            print('importando uxy')
            uxy = uxy_txt.replace('.py', '')
            uxy = importlib.import_module(uxy)
            uxy = uxy.uxy
        else:
            def uxy(x, y, **kwargs):
                kwargs['x'] = x
                kwargs['y'] = y
                utxt = uxy_txt
                for key,val in kwargs.items():
                    utxt = utxt.replace(key, str(val))
                return eval(utxt)
        var_dict['uxy'] = uxy
        n = int(n_box.get())
        data_update('n', n)

        # save
        # with open('datos', 'w+') as ff:
        #     json.dump(var_dict, ff)
        with open('saved_data.json', 'w+') as file_in:
            json.dump(data_json, file_in, indent=4)
        print('Datos ingresados\nCalculando...')

        # config1.destroy()
        for key, value in var_dict.items():
            print(f'{key}: {value}')
    solve_one()
    general['loading'].grid_remove()
    general['start_button'].grid(row=general['button_row'], column=0, columnspan=6, sticky='nsew', padx=10, pady=20)


# button 1
general['button_row'] = next(entry_row)
general['start_button'] = button(entry_frame, text='Iniciar', font=font_title, command=get_config)
general['start_button'].grid(row=general['button_row'], column=0, columnspan=6, sticky='nsew', padx=10, pady=20)

# loading label
general['load_row'] = next(entry_row)
general['loading'] = label(entry_frame, text='Calculando....', font=font_title)
# general['loading'].grid(row=general['load_row'], column=0, columnspan=6, sticky='nsew', padx=10, pady=20)

# loop
config1.mainloop()

print('end program')
