# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 15:37:50 2024

@author: gab_4
"""
import numpy as np

def uxy(x, y, **kwargs):
    if 'k' in kwargs:
        k = kwargs['k']
    if 's' in kwargs:
        s = kwargs['s']
    if 'a' in kwargs:
        a = kwargs['a']


    u = x**2*y**2*(1-x)**2*(1-y)**2
    return u
